require("dotenv").config();
const express = require("express");
const path = require("path");
const generateRoute = require("./routes/generate");

const app = express();

console.log("Loaded OpenAI API Key:", process.env.OPENAI_API_KEY?.slice(0, 10) + "...");

app.use(express.json());
app.use(express.static(path.join(__dirname, "../frontend")));
app.use("/api/generate", generateRoute);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Renewal Playbook Agent is running on http://localhost:${PORT}`);
});