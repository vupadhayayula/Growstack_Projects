const express = require("express");
const router = express.Router();
const OpenAI = require("openai");
const crypto = require("crypto");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const responseCache = new Map();
const usageLog = [];

function hashInput(text) {
  return crypto.createHash("sha256").update(text).digest("hex");
}

router.post("/", async (req, res) => {
  const { customer, plan, renewalDue, engagement, concerns } = req.body;

  const input = `Customer: ${customer}\nPlan: ${plan}\nRenewal Due: ${renewalDue}\nEngagement: ${engagement}\nConcerns: ${concerns}`;
  const inputHash = hashInput(input);

  try {
    usageLog.push({ inputHash, inputText: input, timestamp: new Date().toISOString() });

    if (responseCache.has(inputHash)) {
      return res.json({ strategy: responseCache.get(inputHash) });
    }

    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      temperature: 0,
      messages: [
        {
          role: "system",
          content: "You are a Customer Success agent specialized in generating renewal strategies.",
        },
        {
          role: "user",
          content: `Based on the following customer details, generate a personalized renewal strategy and communication:\n\n${input}`,
        },
      ],
    });

    const strategy = completion.choices?.[0]?.message?.content;

    if (strategy) {
      responseCache.set(inputHash, strategy);
      res.json({ strategy });
    } else {
      res.status(500).json({ error: "No strategy returned from OpenAI." });
    }
  } catch (error) {
    console.error("OpenAI error:", error.message || error);
    res.status(500).json({ error: "Failed to generate strategy." });
  }
});

router.get("/usage-log", (req, res) => {
  res.json({ usage: usageLog });
});

module.exports = router;
