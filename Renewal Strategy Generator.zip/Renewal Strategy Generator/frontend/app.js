const express = require("express");
const path = require("path");
const dotenv = require("dotenv");
const generateRoute = require("./routes/generate");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "../frontend")));

app.use("/api/generate", generateRoute);

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

app.listen(PORT, () => {
  console.log(`Renewal Playbook Agent is running on http://localhost:${PORT}`);
});
