import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import allocateRoutes from './routes/allocate.js';
dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));
app.use('/api/allocate', allocateRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
