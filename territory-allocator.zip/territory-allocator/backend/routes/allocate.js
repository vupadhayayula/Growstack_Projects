import express from 'express';
import multer from 'multer';
import fs from 'fs';
import csv from 'csv-parser';
import { OpenAI } from 'openai';
import dotenv from 'dotenv';
dotenv.config();
const router = express.Router();
const upload = multer({ dest: 'uploads/' });
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});
router.post('/', upload.single('csvfile'), async (req, res) => {
  const filePath = req.file.path;
  const rows = [];
  fs.createReadStream(filePath)
    .pipe(csv())
    .on('data', (row) => rows.push(row))
    .on('end', async () => {
      try {
        fs.unlinkSync(filePath);
        const prompt = `
You are an AI agent that helps assign clients to field agents based on service zone, agent capacity, and proximity.

Using the data provided below, generate a **clean plain English summary**, formatted like a human-readable report.

IMPORTANT:
- DO NOT use JSON.
- DO NOT use code blocks like \`\`\`.
- DO NOT use markdown.
- ONLY return a structured plain text report (like a PDF-style summary).

===============================
🧾 Example Output Format:

=== Territory Allocation Report ===

Agent: John D  
Zone: North Hyderabad  
Clients Assigned:  
- Apollo Pharmacy (C101), Lat: 17.385, Lon: 78.4867, Volume: 120  
- MedPlus (C104), Lat: 17.3862, Lon: 78.4895, Volume: 60  

Unassigned Clients:  
- XYZ Chemist (C109), Zone: South Hyderabad  

Summary:  
Allocated clients to agents based on zone, proximity, and capacity limits.
===============================

Here is the input data:
${JSON.stringify(rows, null, 2)}
        `;
        const response = await openai.chat.completions.create({
          model: "gpt-4",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.3
        });
        const message = response.choices[0].message.content;
        res.type('text').send(message);
      } catch (err) {
        res.status(500).type('text').send(`Error: ${err.message}`);
      }
    });
});
export default router;
