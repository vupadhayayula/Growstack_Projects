async function uploadFile() {
  const fileInput = document.getElementById('csvFile');
  const output = document.getElementById('output');

  if (!fileInput.files.length) {
    alert('Please select a CSV file');
    return;
  }

  const formData = new FormData();
  formData.append('csvfile', fileInput.files[0]);

  output.textContent = "Processing file...";

  try {
    const response = await fetch('http://localhost:5000/api/allocate', {
      method: 'POST',
      body: formData
    });

    const text = await response.text();
    output.textContent = text;

  } catch (err) {
    output.textContent = `Error: ${err.message}`;
  }
}
