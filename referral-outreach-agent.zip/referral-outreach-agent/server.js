require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sgMail = require('@sendgrid/mail');

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

app.post('/api/sendReferral', async (req, res) => {
  const { name, email, message } = req.body;

  const msg = {
    to: email,
    from: process.env.FROM_EMAIL,
    subject: `Referral from our team`,
    text: `Hi ${name},\n\n${message}\n\nBest,\nTeam`,
  };

  try {
    await sgMail.send(msg);
    res.json({ success: true, message: 'Referral sent successfully!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to send referral.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
