document.getElementById('contactForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const name = document.getElementById('name').value;
  const company = document.getElementById('company').value;
  const domain = document.getElementById('domain').value;

  const response = await fetch('http://localhost:5000/api/discover', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, company, domain })
  });

  const data = await response.json();
  document.getElementById('result').innerText = data.email || 'No contact found';
});
