const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

app.post('/api/discover', async (req, res) => {
  const { name, company, domain } = req.body;

  try {
    const prompt = `
You are a contact discovery agent. Based on the following details:
- Name: ${name}
- Company: ${company}
- Domain: ${domain}

Guess the most likely professional email address in the format used by the company. Return only the guessed email address and nothing else.
`;

    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.2
      },
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${OPENAI_API_KEY}`
        }
      }
    );

    const email = response.data.choices[0].message.content.trim();
    res.json({ email });
  } catch (err) {
    console.error('OpenAI API error:', err.message);
    res.status(500).json({ error: 'Failed to generate contact info' });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
