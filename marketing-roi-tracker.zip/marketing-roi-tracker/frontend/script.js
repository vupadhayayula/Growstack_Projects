document.getElementById('roiForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const formData = new FormData(e.target);
  const data = Object.fromEntries(formData.entries());

  const res = await fetch('http://localhost:3000/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });

  const result = await res.json();
  document.getElementById('results').innerHTML = `
    <h3>📊 Results:</h3>
    <p><strong>ROI:</strong> ${result.roi}%</p>
    <p><strong>CPC:</strong> ₹${result.cpc}</p>
    <p><strong>Conversion Rate:</strong> ${result.conversionRate}%</p>
    <h4>🤖 AI Insights:</h4>
    <p>${result.aiInsights}</p>
  `;
});
