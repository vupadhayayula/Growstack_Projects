const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();
const OpenAI = require('openai');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Serve static frontend files
app.use(express.static(path.join(__dirname, '../frontend')));

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.post('/analyze', async (req, res) => {
  try {
    const {
      campaign,
      channel,
      impressions,
      clicks,
      conversions,
      spend,
      revenue
    } = req.body;

    const roi = (((revenue - spend) / spend) * 100).toFixed(2);
    const cpc = (spend / clicks).toFixed(2);
    const conversionRate = ((conversions / clicks) * 100).toFixed(2);

    const prompt = `
Campaign Name: ${campaign}
Channel: ${channel}
Impressions: ${impressions}
Clicks: ${clicks}
Conversions: ${conversions}
Spend: ₹${spend}
Revenue: ₹${revenue}

Calculated Metrics:
- ROI: ${roi}%
- CPC: ₹${cpc}
- Conversion Rate: ${conversionRate}%

Based on these metrics, suggest 3 ways to improve the campaign performance.
    `;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }]
    });

    res.json({
      roi,
      cpc,
      conversionRate,
      aiInsights: completion.choices[0].message.content
    });

  } catch (err) {
    console.error('Error during analysis:', err.message);
    res.status(500).json({ error: 'Something went wrong with ROI analysis.' });
  }
});

app.listen(3000, () => {
  console.log('🚀 Server running at http://localhost:3000');
});
