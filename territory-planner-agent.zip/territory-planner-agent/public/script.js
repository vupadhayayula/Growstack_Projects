document.getElementById('territoryForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const regions = document.getElementById('regions').value;
  const members = document.getElementById('members').value;
  const notes = document.getElementById('notes').value;

  const res = await fetch('/plan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ regions, members, notes })
  });

  const data = await res.json();
  document.getElementById('output').textContent = data.result;
  document.getElementById('resultContainer').classList.remove('hidden');
});
