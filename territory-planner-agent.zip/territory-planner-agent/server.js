const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const cors = require('cors');
const OpenAI = require('openai');

dotenv.config();

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.post('/plan', async (req, res) => {
  const { regions, members, notes } = req.body;

  const prompt = `You are a smart AI assistant that creates optimized sales territories.
Given the following regions: ${regions}, and team members: ${members}, provide an optimal territory plan.
Additional notes: ${notes || 'None'}.
Format the result with clear assignments and balance.`;

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0
    });

    const aiResponse = completion.choices[0].message.content;
    res.json({ result: aiResponse });
  } catch (error) {
    console.error('OpenAI API error:', error);
    res.status(500).json({ result: 'Error generating plan' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
